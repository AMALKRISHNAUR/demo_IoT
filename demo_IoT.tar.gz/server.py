import socket
import random

# Create a socket object
server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Get local machine name
host = socket.gethostname()
port = 9999

# Bind to the port
server_socket.bind((host, port))

# Queue up to 5 requests
server_socket.listen(5)

print(f"Server listening on {host}:{port}")

while True:
    # Establish connection with client
    client_socket, addr = server_socket.accept()
    print(f"Got connection from {addr}")
    
    # Wait for client request
    data = client_socket.recv(1024).decode()
    
    if data == "REQUEST_NUMBER":
        # Generate and send a random number
        number = random.randint(1, 100)
        client_socket.send(str(number).encode())
        print(f"Sent number: {number}")
    
    # Close the connection
    client_socket.close()
