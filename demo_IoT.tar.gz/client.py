import socket

# Create a socket object
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Get local machine name
host = socket.gethostname()
port = 9999

# Connect to the server
client_socket.connect((host, port))

# Send request for number
client_socket.send("REQUEST_NUMBER".encode())

# Receive the number (buffer size is 1024 bytes)
number = client_socket.recv(1024).decode()
print(f"Received number from server: {number}")

# Close the socket
client_socket.close()
