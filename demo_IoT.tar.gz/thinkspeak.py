import requests
import random

def thingspeak_post():

    val = random.randint(1, 3)
    URL = 'https://api.thingspeak.com/update?api_key=C77KTUUDGQLEWHTN&'
    KEY = 'C77KTUUDGQLEWHTN'
    HEADER = '&field1={}&field2={}&field3={}'.format(val, val,val)
    NEW_URL = URL + KEY + HEADER
    print(NEW_URL)
    data = requests.get(NEW_URL)
    print(data)

if __name__ == '__main__':
    thingspeak_post()
