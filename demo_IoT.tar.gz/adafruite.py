import time
import random
from Adafruit_IO import Client, RequestError

# Replace with your Adafruit IO credentials
ADAFRUIT_IO_USERNAME = "Amal_117"
ADAFRUIT_IO_KEY = "aio_QoPT3944YhDdrwz6R6zcen0ktPOO"

# Initialize the REST client
aio = Client(ADAFRUIT_IO_USERNAME, ADAFRUIT_IO_KEY)

# Create or get a feed named 'temperature'
try:
    feed = aio.feeds('temperature')
except RequestError:  # Feed doesn’t exist, create it
    feed = aio.create_feed({'name': 'temperature'})

# Send random temperature data every 5 seconds
print("Sending data to Adafruit IO...")
for _ in range(10):  # Send 10 values
    temp = random.uniform(20.0, 30.0)  # Random temp between 20°C and 30°C
    aio.send_data('temperature', temp)
    print(f"Sent temperature: {temp:.2f}°C")

    # Retrieve the latest value
    data = aio.receive('temperature')
    print(f"Received: {data.value}°C (ID: {data.id})")
    
    time.sleep(5)  # Wait 5 seconds

print("Done!")
