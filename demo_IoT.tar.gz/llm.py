from ollama import chat
from ollama import ChatResponse

response: ChatResponse = chat(model='llama3.2', messages=[
  {
    'role': 'user',
    'content': 'You are whether report maker today the temoperature and humidity are 30degree and 70% give a report',
  },
])
print(response['message']['content'])
# or access fields directly from the response object
#print(response.message.content)

from twilio.rest import Client

account_sid = 'ACfede3683b7ddf50d309726c86f8ff043'
auth_token = '557fb3114b49b3dead72128db5e62d19'
client = Client(account_sid, auth_token)

message = client.messages.create(
  from_='whatsapp:+14155238886',
  content_sid='HXb5b62575e6e4ff6129ad7c8efe1f983e',
  content_variables='{"1":response['message']['content']}',
  to='whatsapp:+918547490327'
)

print(message.sid)
